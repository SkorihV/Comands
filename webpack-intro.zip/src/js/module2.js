export default class Product {
  constructor(name) {
    this.name = name;
  }
}
