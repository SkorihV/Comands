import { conf as c } from './module1';
// import * as mod1 from './module1';
import Product from './module2';

console.log(new Product('Apple'));
console.log(c);
// console.log(mod1.foo());
